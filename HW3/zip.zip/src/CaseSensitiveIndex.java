import java.io.File;
import java.util.TreeSet;

public class CaseSensitiveIndex extends AbstractInvertedIndex{

    public CaseSensitiveIndex(){ }
    // TODO this should be private. its a single tone!

}
